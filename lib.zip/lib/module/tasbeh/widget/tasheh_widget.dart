import 'package:flutter/material.dart';

class tasbeh_view extends StatelessWidget {
  String tasbehName;
  int currentindex=0;
  List<String> changeTasbeh=['allah akber', 'spbhan allah','alhamed u llah'];

  tasbeh_view({super.key,required this.tasbehName});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
